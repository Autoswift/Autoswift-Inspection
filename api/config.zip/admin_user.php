<?php
include_once("src/defalt.php");
if($_SERVER['REQUEST_METHOD']=="GET")
{ 
      $query = "Select * from users WHERE position='Administrator'";
      $result=$exe->getallquerydata($query); 
      if($result){
        $temp=$result;
        $error= "Sucssfully";
          $status = true;
          $code   = "200";
      }else{
        $error="Nodata Found";
      }
    
  echo json_encode(array("data"=>$result,"message" => $error,"status" => $status,"code" => $code)); 
}
?>