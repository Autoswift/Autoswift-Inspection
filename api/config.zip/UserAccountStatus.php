<?php
include_once("src/defalt.php");
if($_SERVER['REQUEST_METHOD']=="POST")
{ 
  $data = $_POST;
  $error = $valid->check_empty($data, array("user_id"));
  if(!$error){
    $result=$exe->getsingledata('users','id',$data['user_id']);
    if($result){
      unset($data['user_id']);
      if(!empty($data['firebase_id'])){
         $res=$exe->update('users',$data,'id',$result['id']);
      }
      if($result['status'] == 'Active' ){
        $temp['user_status']=0;
        $temp['message']="Acount Active";
      }
      if($result['status'] == 'Inactive' ){
        $temp['user_status']=1;
        $temp['message']="Acount Inactive";
      }
      if($result['status'] == 'Requested' ){
        $temp['user_status']=3;
        $temp['message']="User Data Required";
      }
      if($result['status'] == 'Pending' ){
        $temp['user_status']=2;
         $temp['message']="Account Not Appove Yet";
      }
      if($result['status'] == 'Rejected' ){
        $temp['user_status']=4;
        $temp['message']="User is Rejected";
      }
    }
     $status = true;
     $code   = "200";
     $error ="success";
  }
  echo json_encode(array("data"=>$temp,"message" => $error,"success" => $status,"code" => $code)); 
}
?>