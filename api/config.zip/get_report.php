<?php
include_once("src/defalt.php");
if($_SERVER['REQUEST_METHOD']=="POST")
{
  $data = json_decode(file_get_contents('php://input'), true);
  if(!empty($data['user_id']))
  { 
      $limit='';
      if(!empty($data['limit'])){
          $limit= 'LIMIT '.$data['limit']; 
      }
      $sql="Select position,employe_id from users where id=".$data['user_id'];
      $res=$exe->getsinglequery($sql);
      if(!empty($res['position']) && $res['position']!='SuperAdmin'){
          $where="where refenence_no LIKE '".$res['employe_id']."%'";
      }else{
          $where='';
      }
     
	 $query= "SELECT finances.id,finances.user_id,finances.created,finances.registration_no,finances.make_model,finances.financed_by,finances.refenence_no,finances.pdf_file,valuations.name as companyname,users.name,users.position from finances 
left JOIN valuations ON valuations.id = finances.valuatation_by 
left JOIN users ON users.id = finances.user_id $where ORDER BY id desc $limit";
	$result=$exe->getallquerydata($query);
	if(isset($result)){
	    $temp=$result;
	   foreach ($result as $key => $value) {
	        $temp[$key]['date']=date('d-m-Y',strtotime($value['created']));
	        unset($temp[$key]['created']);
	    }
	    
		$error= "Sucssfully";
        $status = true;
        $code   = "200";
	}else{
		$error= "No Data Found";
	}
  }    	
	echo json_encode(array("data" => $temp, "method" =>"Report data","success" => $status, "message" => $msg));	
}
?>