
<?php
include_once("src/defalt.php");
if($_SERVER['REQUEST_METHOD']=="GET")
{	
			$requestData=$_REQUEST;
			$result=[];
			$totalData =0;
			$totalFiltered=0;
			$data=$_GET;
			if(isset($data['filterdata'])){
					$filterdata=array_filter($data['filterdata']);
					$amount='';
					if(!empty($filterdata['amount_from']) AND !empty($filterdata['amount_to']))
					{
					   $amount="AND total_amount BETWEEN '".$filterdata['amount_from']."' AND '".$filterdata['amount_to']."'";
					}
					$created='';
					if(!empty($filterdata['create_date']) AND !empty($filterdata['create_end']))
					{	
						$create_date= date_format(date_create($filterdata['create_date']),"Y-m-d");
						$create_end= date_format(date_create($filterdata['create_end']),"Y-m-d");
					   	$created="AND created BETWEEN '".$create_date."' AND '".$create_end."'";
					}
					unset($filterdata['amount_from']);
					unset($filterdata['amount_to']);
					unset($filterdata['create_date']);
					unset($filterdata['create_end']);
					unset($filterdata['s_date']);
					unset($filterdata['e_date']);
					foreach ($filterdata as $key => $value)
						{
				            $whereArr[] = "$key = '{$value}'";
				        }
					$whereStr = implode(" AND ", $whereArr);
					$query = "Select * from finances WHERE $whereStr $amount $created ORDER BY ID ASC LIMIT ".$requestData['start']." ,".$requestData['length']."";
					 $result=$exe->getallquerydata($query);
					 $sql = "SELECT COUNT(ID) AS total FROM finances WHERE $whereStr $amount $created"; 
					 $row=$exe->getsinglequery($sql);
					 $totalData=$row['total'];
					 $totalFiltered=$row['total'];	 
				}else{
					$sql = "SELECT * FROM finances ORDER BY ID ASC LIMIT ".$requestData['start']." ,".$requestData['length']." ";
					 $result=$exe->getallquerydata($sql); 
					 $sql = "SELECT COUNT(ID) AS total FROM finances"; 
					 $row=$exe->getsinglequery($sql);
					 $totalData=$row['total'];
					 $totalFiltered=$row['total'];
				}
				if($result){
						foreach ($result as $key => $value) {
			 				$result[$key]['report_date']=date('d-m-Y', $value['report_date']);
			 			}
			 		$temp = $result;	
					}
			
		$json_data = array(
	    "draw"            => intval($requestData['draw']),
	    "recordsTotal"    => intval($totalData),
	    "recordsFiltered" => intval($totalFiltered),
	    "data"            => $temp
	);	
		echo json_encode($json_data); 
}
if($_SERVER['REQUEST_METHOD']=="POST")
{	
	$data=$_POST;
	$result=[];
	if($data){

		$data=$exe->escape_stringdata($data);
		if(!empty($_POST['report_id'])){
			$data['updated']=$time;
			unset($data['report_id']);
			$result=$exe->update('finances',$data,'id',$_POST['report_id']);
			if($result==true){
				$temp['ref_id']=$_POST['report_id'];
				$error= "Sucssfully";
			    $status = true;
			    $code   = "200";	
			}else{
				$error=$result;
			}
		}else{
			$data['created']=$time;
			$result=$exe->insert($data,'finances');
			if(isset($result['id'])){
				$temp['ref_id']=$result['id'];
				$error= "Sucssfully";
			    $status = true;
			    $code   = "200";	
			}else{
				$error=$result;
			}
		}
	}
	echo json_encode(array("result"=>$temp,"message" => $error,"status" => $status,"code" => $code)); 
}
if($_SERVER['REQUEST_METHOD']=="DELETE")
{	
	$data  = json_decode(file_get_contents("php://input"), true);
	if(!empty($data['report_id'])){
		$result=$exe->delete($data['report_id'],'finances');
		if($result=="true"){
			$temp['ref_id']=$data['report_id'];
			$error= "Sucssfully";
		    $status = true;
		    $code   = "200";
		}else{
			$error=$result;
		}
	}else{
		$error="Missing Parameters";
	}
	echo json_encode(array("result"=>$temp,"message" => $error,"status" => $status,"code" => $code)); 
}
?>