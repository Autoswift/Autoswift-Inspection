<?php
class DatabaseService {
 private $db_host = "localhost";
 private $db_name = "webvep3v_auto";
 private $db_user = "webvep3v_auto";
 private $db_password = "1+l80DU^TYH4";
 protected $conn;
 public function __construct()
 {
    if (!isset($this->conn)) {
        $this->conn = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name);
        if (!$this->conn) {
            echo 'Cannot connect to database server';
            exit;
        }            
    }    
    return $this->conn;
 }
  
}
?>