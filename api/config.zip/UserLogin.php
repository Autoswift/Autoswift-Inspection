<?php
include_once("src/defalt.php");

if($_SERVER['REQUEST_METHOD']=="POST")
{	
	$data = $_POST;
		$fields=array("mobile_number",'password','device_id','firebase_id','location');
		$error = $valid->check_extrafields($data,$fields);
	if(!$error){
		$error = $valid->check_empty($data, array("mobile_number",'password'));
		if(!$error){
			$data=$exe->escape_stringdata($data);
			$result=$exe->getsingledata('users','username',$data['mobile_number']);
			if($result){
					if($result['pass1']==$data['password']){
						unset($data['password']);
					  $res=$exe->update('users',$data,'id',$result['id']);
					  $temp['id']=$result['id'];
					  $temp['profile_name']=$result['profile_name'];
					  $temp['name']=$result['name'];
					  $temp['employe_id']=$result['employe_id'];
					  $temp['position']=$result['position'];
					  $temp['firebase_id']=$result['firebase_id'];
					  if($result['position']=='Employe'){
					      $temp['is_user']=0;
					  }
					  if($result['position']=='SuperAdmin'){
					      $temp['is_user']=1;
					  }
					  if($result['position']=='Admin'){
					      $temp['is_user']=2;
					     $temp['comp_id']=8;
					  }
					  $error= "Sucssfully";
		              $status = true;
		              $code   = "200";
					}else
					$error= "Invalid Credentials";
					}	
			else{
				$error= "Invalid Credentials";
			}
		}
		
	}
	echo json_encode(array("data"=>$temp,"message" => $error,"success" => $status,"code" => $code)); 
}

?>