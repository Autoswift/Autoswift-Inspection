<?php
include_once("src/defalt.php");
if($_SERVER['REQUEST_METHOD']=="GET")
{	
		$sql='';
		$result='';
		if(!empty($_GET['user_id'])){
			$sql="select notification.*,users.name as excutive_name,area.name as area,valuations.name as company_name From notification,users,area,valuations where valuations.id=notification.valuations_by AND notification.user_id=users.id and area.id=notification.area and notification.user_id=".$_GET['user_id'];
			
		}else if(!empty($_GET['sender_id'])){
		   $sql="select notification.*,users.name as excutive_name,area.name as area,valuations.name as company_name From notification,users,area,valuations where valuations.id=notification.valuations_by AND notification.user_id=users.id and area.id=notification.area and notification.sender_id=".$_GET['sender_id'];
		}
		if($sql){
			$result=$exe->getallquerydata($sql);	
		}
		if($result){
			$temp=$result;
	 		$error= "Sucssfully";
		    $status = true;
		    $code   = "200";
		}else{
			$error="Nodata Found";
		}
	echo json_encode(array("data"=>$result,"message" => $error,"status" => $status,"code" => $code)); 
}
if($_SERVER['REQUEST_METHOD']=="POST")
{	
	$data=$_POST;
	$error=$valid->check_empty($data,array('valuations_by','area','registration_no','make_model','party_name','mobile_no','place','payment','user_id','sender_id'));
	if(!$error){
		$data=$exe->escape_stringdata($data);
		$error=$valid->validate_phone_number($data['mobile_no']);
			if(!$error){
					if(!empty($_POST['not_id'])){
					$data['date']=$time;
					unset($data['not_id']);
					$result=$exe->update('notification',$data,'id',$_POST['not_id']);
						if($result=="true"){
							$temp['ref_id']=$_POST['not_id'];
							$error= "Update Sucssfully";
						    $status = true;
						    $code   = "200";	
						}else{
							$error=$result;
						}
					}else{
						$data['date']=$time;
						unset($data['not_id']);
						$result=$exe->insert($data,'notification');
							if(isset($result['id'])){
								$temp['ref_id']=$result['id'];
								$error= "Sucssfully";
							    $status = true;
							    $code   = "200";	
							}else{
								$error=$result;		
							}
					}
		}

	}
	echo json_encode(array("data"=>$temp,"message" => $error,"status" => $status,"code" => $code)); 
}

?>