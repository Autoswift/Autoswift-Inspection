<?php
ini_set('display_errors', 1);
include_once("src/defalt.php");
date_default_timezone_set('Asia/Kolkata');
$msg = "";
$status = false;
$login_time  = date('Y-m-d G:i:s');
$time=date('YmdGis');
$filedata=[];
$data=array();

if (@$_SERVER['REQUEST_METHOD'] == 'POST') {
    $tab_1 = json_decode($_POST['tab_1'],true);
    $user_id = trim($tab_1['user_id']);
    $appliction_no = trim($_POST['appliction_no']);
    $data1['user_id']=$user_id;
    $device_id = trim($tab_1['device_id']);
    $data1['device_id']=$device_id;
    $ref_no = trim($tab_1['ref_no']);
    $companyname = trim($tab_1['companyname']);
    $c_exe_name = trim($tab_1['c_exe_name']);
    $inspection_date = trim($tab_1['inspection_date']);
    $place_valuation=trim($tab_1['place_valuation']);
    $registration_no=trim($tab_1['registration_no']);
    $make_model = trim($tab_1['make_model']);
    $chassis_no = trim($tab_1['chassis_no']);
    $engine_no = trim($tab_1['engine_no']);
    $mm_reading =trim($tab_1['mm_reading']);
    $color =trim($tab_1['color']);
    $battery =trim($tab_1['battery']);
    $radiator =trim($tab_1['radiator']);
    $reg_owner =trim($tab_1['reg_owner']);
    $finance_take_name=trim($tab_1['finance_take_name']);
    $mobile_no=trim($tab_1['mobile_no']);
   
    $tab_2 = json_decode($_POST['tab_2'],true);
    $ac = trim($tab_2['ac']);
    $power_steering = trim($tab_2['power_steering']);
    $power_window  = trim( $tab_2['power_window']);
    $air_bag = trim($tab_2['air_bag']);
    //$data['TYERS']= json_decode(trim($_POST['tyers']),true);
    $tab_3 = json_decode($_POST['tab_3'],true);
    $data = $tab_3; 
    $comment = trim($tab_3['comment']);
    $total_amount = trim($tab_3['total_amount']);
    $paid_amount  = trim($tab_3['paid_amount']);
    $remaining_amount = trim($tab_3['remaining_amount']);
    
 if($user_id!="")
 {
  
  $right_tyres=[]; $right_COM=[];$right_QTY=[];
  foreach ($tab_2['right_tyres'] as $value) 
  {
    $right_tyres[].= $value['NO_OF_TY'];
    $right_COM[].= $value['COM'];
    $right_QTY[].= $value['QTY'];
  }
   $left_tyres=[]; $left_COM=[];$left_QTY=[];
  foreach ( $tab_2['left_tyres'] as $value) 
  {
    $left_tyres[].= $value['NO_OF_TY'];
    $left_COM[].= $value['COM'];
    $left_QTY[].= $value['QTY'];
  }
  $rh_tyres=json_encode($right_tyres);
  $rh_company =json_encode($right_COM);
  $rh_quality =json_encode($right_QTY);
  
  $lh_tyres=json_encode($left_tyres);
  $lh_company =json_encode($left_COM);
  $lh_quality =json_encode($left_QTY);
  if(isset($_FILES['fr_rh_side'])&&isset($_FILES['fr_lh_side'])&&isset($_FILES['rr_rh_side'])&&isset($_FILES['rr_lh_side'])&&isset($_FILES['chassis_number'])&&isset($_FILES['engine_photo'])&&isset($_FILES['km_reading'])&&isset($_FILES['battery_img'])&&isset($_FILES['engine_no_plate'])&&isset($_FILES['driver_door'])&&isset($_FILES['steering'])&&isset($_FILES['dasboard'])&&isset($_FILES['rh_front_tyre'])&&isset($_FILES['rh_rear_tyre'])&&isset($_FILES['lh_front_tyre'])&&isset($_FILES['lh_rear_tyre'])&&isset($_FILES['rc_side1'])&&isset($_FILES['rc_side2'])&&isset($_FILES['chassis_photo'])&&isset($_FILES['selfie']))
  {
   foreach ($_FILES as $key => $value)
     {
      if($key=='chassis_photo'||$key=='selfie')
      {
          $RandomString = substr(str_shuffle(md5(time())), 0,10);
          $data[$key]= $user_id.$RandomString.$_FILES[$key]['name'];
          move_uploaded_file($_FILES[$key]["tmp_name"],"../uploads/finance/".basename($user_id. $RandomString.$_FILES[$key]['name']));  
      } else{
        $RandomString = substr(str_shuffle(md5(time())), 0,10);
        $filedata[]=$user_id.$RandomString.$_FILES[$key]['name'];
        $data[$key]= $user_id.$time.$_FILES[$key]['name'];
        move_uploaded_file($_FILES[$key]["tmp_name"],"../uploads/finance/".basename($user_id.$RandomString.$_FILES[$key]['name'])); 
      }
      
     }
    $filedata1=json_encode($filedata); 
    $sql ="INSERT INTO `finances`(`user_id`,`refenence_no`,`appliction_no`,`valuatation_by`,`financer_representative`,`inspection_date`,`place_of_valuation`,`Registration_no`,`make_model`,`chachees_number`,`engine_number`,`mm_reading`,`color`,`battery`,`radiator`,`registerd_owner`,`financed_by`,`Mobile_no`,`ac`, `power_steering`,`power_window`,`air_bag`,`right_tyer_quantity`,`left_tyer_quantity`,`right_tyer_company`,`left_tyer_company`,`right_quality`,`left_quality`,`general_comment`, `total_amount`,`amount_paid`,`remaining_amount`,`chachees_number_photo`,`selfie`,`photo`,`created`) VALUES ('".$user_id."','".$ref_no."','".$appliction_no."','".$companyname."','".$c_exe_name."','".$inspection_date."','".$place_valuation."','".$registration_no."','".$make_model."','".$chassis_no."','".$engine_no."','".$mm_reading."','".$color."','".$battery."','".$radiator."','".$reg_owner."','".$finance_take_name."','".$mobile_no."','".$ac."','".$power_steering."','".$power_window."','".$air_bag."','".$rh_tyres."','".$lh_tyres."','".$rh_company."','".$lh_company."','".$rh_quality."','".$lh_quality."','".$comment."','".$total_amount."','".$paid_amount."','".$remaining_amount."','".$data['chassis_photo']."','".$data['selfie']."','".$filedata1."','".$login_time."')";
    $res=$exe->inserquery($sql); 
   if(isset($res['id']))
   {  
     $data1['report_id']=$res['id'];
     $msg ='Successfully';
     $status = true;
   }else{
      $msg=$res;
   }
  } 
   
  }
  else {
    $msg = 'Missing parameters.';
  }  
  
 }
  
 $data_tmp = array("data" => $data1, "method" =>"Report Submit Successfully","success" => $status, "message" => $msg);
//header('Content-type: application/json');
echo json_encode($data_tmp);

?>